import flet as ft

import components.editor as Editor
import components.sources as Sources
import components.constants as Constants

import src.general as General

def main(page):
    mainState = General.MainState(page)
    editorKeys = Editor.Keys(mainState, page)

    page.adaptive = True
    page.title = "Carite Editor"
    page.window.prevent_close = True
    page.window.maximized=True

    ### manual closing functionality
    def mainPageCheckClose(e):
        if e.data != "close":
            return
        if mainState.has_changes == False:
            page.window.destroy()
            return
        confirmclose = ft.AlertDialog(
            modal=True,
            title=ft.Text("Caution!"),
            content=ft.Text("You have unsaved changes. Are you sure you want to close without saving?"),
            actions=[
                ft.ElevatedButton("Yes", on_click = lambda e: page.window.destroy()),
                ft.OutlinedButton("No", on_click = lambda e: page.close(confirmclose)),
            ],
            actions_alignment=ft.MainAxisAlignment.END,
        )
        page.open(confirmclose)

    page.window.on_event = mainPageCheckClose

    def editNavBar(selection):
        if mainState.has_changes == True:
            # avoid changing navbar with changes!
            page.navigation_bar.selected_index = mainState.open_bottom_tab
            page.update()
            return
        page.clean()
        if selection == 0:
            editorKeys.editorSetUp()
        if selection == 1:
            Sources.sourcesSetUp(page, mainState)

    page.navigation_bar = ft.NavigationBar(
        destinations=[
            ft.NavigationBarDestination(icon=ft.icons.MODE_EDIT_OUTLINED, selected_icon=ft.icons.MODE_EDIT_SHARP, label="Editor"),
            ft.NavigationBarDestination(icon=ft.icons.SOURCE_OUTLINED, selected_icon=ft.icons.SOURCE_SHARP, label="Sources"),
            ft.NavigationBarDestination(icon=ft.icons.PICTURE_AS_PDF_OUTLINED, selected_icon=ft.icons.PICTURE_AS_PDF_SHARP, label="Export"),
        ],
        border=ft.Border(
            top=ft.BorderSide(color=ft.cupertino_colors.SYSTEM_GREY2, width=0)
        ),
        on_change=lambda e: editNavBar(e.control.selected_index),
    )

    editNavBar(mainState.open_bottom_tab)
    editorKeys.loadStage(mainState.preferences["last_opened_stage"])

ft.app(target=main)

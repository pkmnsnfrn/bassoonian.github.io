import flet as ft

from src.can_save import CanSave
import src.general as general
import src.sound_changes as sound_changes

class Keys:
    def __init__(self, mainState, page):
        self.mainState = mainState
        self.page = page
        # global saved values
        self.alertdialog = ft.AlertDialog()
        self.confirmdialogtext = ft.Text("")
        self.confirmdialogbutton = ft.ElevatedButton("Yes")
        self.confirmdialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("Caution!"),
            content=self.confirmdialogtext,
            actions=[
                ft.OutlinedButton("No", on_click = lambda e: page.close(self.confirmdialog)),
                self.confirmdialogbutton,
            ],
            actions_alignment=ft.MainAxisAlignment.END,
        )
        self.savebutton = ft.NavigationRailDestination()
        self.stageselect = ft.Dropdown(label="Stage", options=[], width=100, on_change = lambda e: self.trySwitchChange(e.control.value))
        for x in mainState.database["stage_data"]:
            self.stageselect.options.append(ft.dropdown.Option(x["information"]["abbr"]))
        # information
        self.information = {
            "language_name": ft.TextField(label="Name", adaptive=False, on_change = lambda e: self.updateField("information", "name", e.control.value)),
            "abbreviation": ft.TextField(label="Abbreviation", adaptive=False, on_change = lambda e: self.updateField("information", "abbr", e.control.value)),
            # inflection
            "inflection_cases": ft.TextField(label="Cases (nouns)", adaptive=False, expand=True, multiline=True, min_lines=3, disabled=True),
            "inflection_number": ft.TextField(label="Number", adaptive=False, expand=True, multiline=True, min_lines=2, disabled=True),
            "inflection_gender": ft.TextField(label="Gender", adaptive=False, expand=True, multiline=True, min_lines=2, disabled=True),
        }
        # sound changes
        self.sound_changes = {
            # navigation
            "slider": ft.Slider(min = 0, max = 0, divisions = 1, adaptive = False, expand=True, on_change = lambda e: self.loadSoundChange(self.mainState.open_stage, int(e.control.value))),
            "sc_summary": ft.TextField(label="Summary (internal)", adaptive=False, expand=True, on_change = lambda e: self.updateSoundChangeData("summary", e.control.value)),
            "sc_counter": ft.Text("", theme_style=ft.TextThemeStyle.TITLE_LARGE),
            # actual fields
            "newchapter": ft.TextField(label="New section", adaptive=False, expand=True, on_change = lambda e: self.updateSoundChangeData("section", e.control.value)),
            "prose": ft.TextField(label="Prose", adaptive=False, expand=True, multiline=True, min_lines=3, on_change = lambda e: self.updateSoundChangeProse(e.control.value)),
            "internalnotes": ft.TextField(label="Internal notes", adaptive=False, expand=True, multiline=True, min_lines=3, on_change = lambda e: self.updateSoundChangeData("internalnotes", e.control.value)),
            "prose_rendered": ft.Markdown("", expand=True),
            "recursive": ft.Checkbox(label="Recursive", value=False, disabled=True, on_change = lambda e: self.updateSoundChangeData("repeat", e.control.value)),
            "sporadicityrate": ft.Text(""),
            "sporadicity": ft.Slider(min=0, max=100, divisions=100, label="{value}%", adaptive=False, disabled=True, on_change = lambda e: self.updateSoundChangeData("rate", int(e.control.value))),
            "regexentry": ft.TextField(label="Regex", adaptive=False, expand=True, multiline=True, min_lines=3, disabled=True, on_change = lambda e: self.updateSoundChangeData("changes", e.control.value)),
            # top buttons
            "lock": ft.FloatingActionButton(icon=ft.icons.LOCK, tooltip="Toggle Sound Change Mode", on_click = lambda e: self.toggleSoundChangeLock()),
            "addsc": ft.FloatingActionButton(icon=ft.icons.ADD, disabled = True, bgcolor = ft.colors.SECONDARY, tooltip="Add Sound Change", on_click = lambda e: self.insertSoundChange()),
            "deletesc": ft.FloatingActionButton(icon=ft.icons.DELETE, disabled = True, bgcolor = ft.colors.SECONDARY, tooltip="Delete Sound Change", on_click = lambda e: self.deleteSoundChange()),
            "move_back": ft.FloatingActionButton(icon=ft.icons.UNDO, disabled = True, bgcolor = ft.colors.SECONDARY, tooltip="Move back", on_click = lambda e: self.swapSoundChange(-1)),
            "move_forward": ft.FloatingActionButton(icon=ft.icons.REDO, disabled = True, bgcolor = ft.colors.SECONDARY, tooltip="Move forward", on_click = lambda e: self.swapSoundChange(1)),
        }
        # grammar
        self.grammar = {
            # nouns
            "noun_dropbox": ft.Dropdown(label="Declension", options=[], expand=True, on_change = lambda e: self.openDeclension(general.getNameToId(self.mainState.database["stage_data"][self.mainState.open_stage]["declensions"])[e.control.value])),
            "noun_add": ft.FloatingActionButton(icon=ft.icons.ADD, tooltip="Add Declension", on_click = lambda e: self.addNewDeclension()),
            "noun_name": ft.TextField(label="Declension name", adaptive=False, expand=True, disabled=True, on_change = lambda e: self.updateDeclensionName(e.control.value)),
            "noun_datatable": ft.DataTable(columns=[ft.DataColumn(ft.Text(""))])
        }
        # lexicon
        self.lexicon = {
            # modal content
            "modal_title": ft.Text("test")
        }
        self.lexicon_add_modal = ft.AlertDialog(
            title=ft.Text("Add an Entry"),
            content=ft.Text("Choose an origin for this entry."),
            actions=[
                ft.OutlinedButton("Inherited", on_click = lambda e: self.openLexiconCategory("test haha")),
                ft.OutlinedButton("Derived", on_click = lambda e: page.close(self.lexicon_add_modal)),
                ft.OutlinedButton("Loaned", on_click = lambda e: page.close(self.lexicon_add_modal)),
                ft.OutlinedButton("Ex Nihilo", on_click = lambda e: page.close(self.lexicon_add_modal)),
                ft.OutlinedButton("Cancel", on_click = lambda e: page.close(self.lexicon_add_modal)),
            ],
            actions_alignment=ft.MainAxisAlignment.END,
        )
        self.lexicon_add_modal2 = ft.AlertDialog(
            title=self.lexicon["modal_title"],
            modal=True,
            content=ft.Column([
                ft.Row([ft.Text("test"), ft.TextField(label="test", adaptive=False)]),
                ft.Row([ft.FloatingActionButton(icon=ft.icons.REDO, tooltip="Save", on_click = lambda e: self.swapSoundChange(1)),
                        ft.FloatingActionButton(icon=ft.icons.REDO, tooltip="Cancel", on_click = lambda e: self.swapSoundChange(1))])
                ])
        )

    def warning(self, title, text):
        self.alertdialog.title = ft.Text(title)
        self.alertdialog.content = ft.Text(text)
        self.page.open(self.alertdialog)

    def yesNoModal(self, text, yesfunction):
        self.confirmdialogtext.value = text
        self.confirmdialogbutton.on_click = yesfunction
        self.page.open(self.confirmdialog)
    
    #### LOAD STAGE ####
    def loadStage(self, stage):
        # information
        self.information["language_name"].value = self.mainState.database["stage_data"][stage]["information"]["name"]
        self.information["abbreviation"].value = self.mainState.database["stage_data"][stage]["information"]["abbr"]
        self.information["inflection_cases"].value = general.arr_to_textbox(self.mainState.database["stage_data"][stage]["information"]["cases"])
        self.information["inflection_number"].value = general.arr_to_textbox(self.mainState.database["stage_data"][stage]["information"]["numbers"])
        self.information["inflection_gender"].value = general.arr_to_textbox(self.mainState.database["stage_data"][stage]["information"]["genders"])
        # sound changes
        if stage > 0:
            self.sound_changes["slider"].max = len(self.mainState.database["stage_data"][stage]["sound_changes"]) - 1
            self.sound_changes["slider"].divisions = len(self.mainState.database["stage_data"][stage]["sound_changes"]) - 1
            self.loadSoundChange(stage, 0)
        # grammar
        if stage == 0:
            self.grammar["noun_add"].visible = True
        else:
            self.grammar["noun_add"].visible = False
        self.mainState.declension_opened = -1
        self.grammar["noun_name"].value = ""
        self.grammar["noun_name"].disabled = True
        self.clearGrammarTable("noun_datatable")
        self.prepareGrammarDropdown("noun_dropbox", self.mainState.database["stage_data"][stage]["declensions"])

        self.stageselect.value = self.mainState.database["stage_data"][stage]["information"]["abbr"]
        self.page.update()

    def updateField(self, category, key, value):
        self.mainState.database["stage_data"][self.mainState.open_stage][category][key] = value.strip()
        self.markAsChanged()

    ### SOUND CHANGE FUNCTIONS
    def loadSoundChange(self, stage, index):
        self.sound_changes["sc_counter"].value = "(%s/%s)" % (int(self.sound_changes["slider"].value + 1), self.sound_changes["slider"].max + 1)
        self.sound_changes["sc_summary"].value = self.mainState.database["stage_data"][stage]["sound_changes"][index]["summary"]
        self.sound_changes["newchapter"].value = self.mainState.database["stage_data"][stage]["sound_changes"][index]["section"]
        self.sound_changes["prose"].value = self.mainState.database["stage_data"][stage]["sound_changes"][index]["prose"]
        self.sound_changes["prose_rendered"].value = self.mainState.database["stage_data"][stage]["sound_changes"][index]["prose"]
        self.sound_changes["internalnotes"].value = self.mainState.database["stage_data"][stage]["sound_changes"][index]["internalnotes"]
        self.sound_changes["recursive"].value = self.mainState.database["stage_data"][stage]["sound_changes"][index]["repeat"]
        self.sound_changes["sporadicity"].value = self.mainState.database["stage_data"][stage]["sound_changes"][index]["rate"]
        self.sound_changes["sporadicityrate"].value = str(int(self.mainState.database["stage_data"][stage]["sound_changes"][index]["rate"])) + "%"
        self.sound_changes["regexentry"].value = general.arr_to_textbox(self.mainState.database["stage_data"][stage]["sound_changes"][index]["changes"])
        if (self.mainState.sc_editing_mode == True):
            if (index == 0):
                general.disableButton(self.sound_changes["move_back"])
            else:
                general.enableButton(self.sound_changes["move_back"])
            if (index == len(self.mainState.database["stage_data"][self.mainState.open_stage]["sound_changes"]) - 1):
                general.disableButton(self.sound_changes["move_forward"])
            else:
                general.enableButton(self.sound_changes["move_forward"])
        self.page.update()

    def updateSoundChangeData(self, key, value):
        if isinstance(value, str):
            value = value.strip()
            if isinstance(self.mainState.database["stage_data"][self.mainState.open_stage]["sound_changes"][int(self.sound_changes["slider"].value)][key], list):
                self.mainState.database["stage_data"][self.mainState.open_stage]["sound_changes"][int(self.sound_changes["slider"].value)][key] = general.textbox_to_arr(value)
                self.markAsChanged()
                return

        self.mainState.database["stage_data"][self.mainState.open_stage]["sound_changes"][int(self.sound_changes["slider"].value)][key] = value
        self.markAsChanged()

    def updateSoundChangeProse(self, value):
        self.sound_changes["prose_rendered"].value = value
        self.mainState.database["stage_data"][self.mainState.open_stage]["sound_changes"][int(self.sound_changes["slider"].value)]["prose"] = value.strip()
        self.markAsChanged()

    def insertSoundChange(self):
        self.mainState.database["stage_data"][self.mainState.open_stage]["sound_changes"].insert(int(self.sound_changes["slider"].value) + 1, general.getEmptySoundChange(int(self.sound_changes["slider"].value) + 2))
        self.sound_changes["slider"].max = len(self.mainState.database["stage_data"][self.mainState.open_stage]["sound_changes"]) - 1
        self.sound_changes["slider"].divisions = len(self.mainState.database["stage_data"][self.mainState.open_stage]["sound_changes"]) - 1
        self.sound_changes["slider"].value += 1
        self.loadSoundChange(self.mainState.open_stage, int(self.sound_changes["slider"].value))

    def swapSoundChange(self, offset):
        tmp = self.mainState.database["stage_data"][self.mainState.open_stage]["sound_changes"][int(self.sound_changes["slider"].value)]
        self.mainState.database["stage_data"][self.mainState.open_stage]["sound_changes"][int(self.sound_changes["slider"].value)] = self.mainState.database["stage_data"][self.mainState.open_stage]["sound_changes"][int(self.sound_changes["slider"].value) + offset]
        self.mainState.database["stage_data"][self.mainState.open_stage]["sound_changes"][int(self.sound_changes["slider"].value) + offset] = tmp
        self.sound_changes["slider"].value += offset
        self.loadSoundChange(self.mainState.open_stage, int(self.sound_changes["slider"].value))

    def deleteSoundChange(self):
        if len(self.mainState.database["stage_data"][self.mainState.open_stage]["sound_changes"]) <= 1:
            self.warning("Error!", "Can't delete the only remaining sound change of a stage!")
            return
        self.yesNoModal("Are you sure you want to delete this sound change?", lambda e: self.deleteSoundChange2())
        
    def deleteSoundChange2(self):
        self.mainState.database["stage_data"][self.mainState.open_stage]["sound_changes"].pop(int(self.sound_changes["slider"].value))
        self.sound_changes["slider"].max = len(self.mainState.database["stage_data"][self.mainState.open_stage]["sound_changes"]) - 1
        self.sound_changes["slider"].divisions = len(self.mainState.database["stage_data"][self.mainState.open_stage]["sound_changes"]) - 1
        if self.sound_changes["slider"].value >= len(self.mainState.database["stage_data"][self.mainState.open_stage]["sound_changes"]):
            self.sound_changes["slider"].value -= 1
        self.loadSoundChange(self.mainState.open_stage, int(self.sound_changes["slider"].value))
        self.page.close(self.confirmdialog)

    def toggleSoundChangeLock(self):
        if self.mainState.sc_editing_mode == False:
            # refuse if there are unsaved changes
            if self.mainState.has_changes == True:
                self.warning("Wait!", "Please save your unsaved changes first.")
                return
            # lock
            self.sound_changes["lock"].icon = ft.icons.LOCK_OPEN
            self.sound_changes["lock"].bgcolor = ft.colors.TERTIARY
            # disable newchapter & prose
            self.sound_changes["newchapter"].disabled = True
            self.sound_changes["prose"].disabled = True
            self.sound_changes["internalnotes"].disabled = True
            self.sound_changes["sc_summary"].disabled = True
            # enable addsc and deletesc
            general.enableButton(self.sound_changes["addsc"])
            general.enableButton(self.sound_changes["deletesc"])
            if (int(self.sound_changes["slider"].value) != 0):
                general.enableButton(self.sound_changes["move_back"])
            if (int(self.sound_changes["slider"].value) != len(self.mainState.database["stage_data"][self.mainState.open_stage]["sound_changes"]) - 1):
                general.enableButton(self.sound_changes["move_forward"])
            # advanced settings
            self.sound_changes["recursive"].disabled = False
            self.sound_changes["sporadicity"].disabled = False
            self.sound_changes["regexentry"].disabled = False
            # main state
            self.mainState.sc_editing_mode = True
        else:
            # verify regex legitimaticy
            for i, sc in enumerate(self.mainState.database["stage_data"][self.mainState.open_stage]["sound_changes"]):
                if sound_changes.editing_format_to_regex(sc["changes"]) == False:
                    self.warning("Wait!", "The regex of %s/%s %s is invalid." % (i + 1, len(self.mainState.database["stage_data"][self.mainState.open_stage]["sound_changes"]), sc["summary"]))
                    return
            # lock
            self.sound_changes["lock"].icon = ft.icons.LOCK
            self.sound_changes["lock"].bgcolor = None
            # enable newchapter & prose
            self.sound_changes["newchapter"].disabled = False
            self.sound_changes["prose"].disabled = False
            self.sound_changes["internalnotes"].disabled = False
            self.sound_changes["sc_summary"].disabled = False
            # disable addsc and deletesc
            general.disableButton(self.sound_changes["addsc"])
            general.disableButton(self.sound_changes["deletesc"])
            general.disableButton(self.sound_changes["move_back"])
            general.disableButton(self.sound_changes["move_forward"])
            # advanced settings
            self.sound_changes["recursive"].disabled = True
            self.sound_changes["sporadicity"].disabled = True
            self.sound_changes["regexentry"].disabled = True
            # main state
            self.mainState.sc_editing_mode = False
            ### TO DO: actually reapply sound changes all over again & save!
            self.saveDatabase()
        self.page.update()

    #### GRAMMAR FUNCTIONS ####
    def clearGrammarTable(self, table):
        self.grammar[table].columns = [ft.DataColumn(ft.Text("Please load a declension."))]
        self.grammar[table].rows = []

    def updateDeclensionName(self, value):
        self.mainState.database["stage_data"][self.mainState.open_stage]["declensions"][self.mainState.declension_opened]["name"] = value
        self.prepareGrammarDropdown("noun_dropbox", self.mainState.database["stage_data"][self.mainState.open_stage]["declensions"])
        self.grammar["noun_dropbox"].value = value
        self.markAsChanged()

    def updateDeclensionEnding(self, destination, value):
        coords = destination.split("/")
        self.mainState.database["stage_data"][self.mainState.open_stage]["declensions"][self.mainState.declension_opened]["content"][int(coords[0])][int(coords[1])] = value
        self.markAsChanged()

    def addNewDeclension(self):
        key = general.getUniqueId()
        dc = general.getEmptyDeclension(key, self.mainState.database["stage_data"][self.mainState.open_stage]["information"]["cases"], self.mainState.database["stage_data"][self.mainState.open_stage]["information"]["numbers"])
        self.mainState.database["stage_data"][self.mainState.open_stage]["declensions"][key] = dc
        self.grammar[key].value = key
        self.openDeclension(key)
        self.markAsChanged()

    def openDeclension(self, key):
        self.grammar["noun_name"].disabled = False
        self.grammar["noun_name"].value = self.mainState.database["stage_data"][self.mainState.open_stage]["declensions"][key]["name"]
        self.mainState.declension_opened = key
        cols = [ft.DataColumn(ft.Text(""))]
        for x in self.mainState.database["stage_data"][self.mainState.open_stage]["information"]["numbers"]:
            cols.append(ft.DataColumn(ft.Text(x)))
        self.grammar["noun_datatable"].columns=cols
        rows = []
        for i, x in enumerate(self.mainState.database["stage_data"][self.mainState.open_stage]["information"]["cases"]):
            rows2 = [ft.DataCell(ft.Text(x))]
            for j, bleh in enumerate(self.mainState.database["stage_data"][self.mainState.open_stage]["information"]["numbers"]):
                if self.mainState.open_stage == 0:
                    rows2.append(ft.DataCell(ft.TextField(hint_text="%s/%s" % (j, i), value=self.mainState.database["stage_data"][self.mainState.open_stage]["declensions"][key]["content"][j][i], adaptive=False, expand=True, on_change = lambda e: self.updateDeclensionEnding(e.control.hint_text, e.control.value))))
                else:
                    rows2.append(ft.DataCell(ft.Text("to do")))
            rows.append(ft.DataRow(cells=rows2))
        self.grammar["noun_datatable"].rows = rows
        self.page.update()

    def prepareGrammarDropdown(self, key, dic):
        k = general.getNameToId(dic)
        self.grammar[key].value = ""
        self.grammar[key].options = [ft.dropdown.Option(x) for x in k]

    #### LEXICON ####
    def openLexiconCategory(self, cat):
        self.page.close(self.lexicon_add_modal)
        self.lexicon["modal_title"].value = "Adding new entry"
        self.mainState.lexicon_entry_opened = -1
        self.page.update()
        self.page.open(self.lexicon_add_modal2)

    #### SAVE FUNCTIONS ####
    def updateSaveLook(self):
        if self.mainState.has_changes == True:
            self.savebutton.icon = ft.icons.SAVE_OUTLINED
            self.savebutton.label = "Save"
        else:
            self.savebutton.icon = ft.icons.CHECK_OUTLINED
            self.savebutton.label = "Saved!"
        self.page.update()

    def saveDatabase(self):
        if not CanSave(self):
            return
        self.mainState.saveInformation()
        self.updateSaveLook()

    def markAsChanged(self):
        self.mainState.has_changes = True
        if not "*" in self.page.title:
            self.page.title += "*"
        self.updateSaveLook()

    #### NAVIGATION HELPERS ####
    def SCNavSlide(self, amount):
        self.sound_changes["slider"].value = min(max(0, self.sound_changes["slider"].value + amount), self.sound_changes["slider"].max)
        self.loadSoundChange(self.mainState.open_stage, int(self.sound_changes["slider"].value))

    def trySwitchChange(self, destination):
        # refuse if there are unsaved changes
        if self.mainState.has_changes == True or self.mainState.sc_editing_mode == True:
            self.warning("Wait!", "Please save your unsaved changes first.")
            self.stageselect.value = self.mainState.database["stage_data"][self.mainState.open_stage]["information"]["abbr"]
            self.page.update()
            return
        stagid = -1
        for i, x in enumerate(self.mainState.database["stage_data"]):
            if x["information"]["abbr"] == destination:
                stagid = i
                break
        if stagid == -1: #failsafe
            self.stageselect.value = self.mainState.database["stage_data"][self.mainState.open_stage]["information"]["abbr"]
            return
        self.mainState.open_stage = stagid
        self.mainState.preferences["last_opened_stage"] = stagid
        self.loadStage(stagid)

    #### SET UP EDITOR ####
    def editorSetUp(self):
        ##### RIGHT CONTENT #####
        right_content = []
        ### INFORMATION
        right_content.append(
            ft.Tabs(
                    tabs=[
                        ft.Tab(
                            text="Nomenclature",
                            content=ft.Row([
                                self.information["language_name"],
                                self.information["abbreviation"]
                            ])
                        ),
                        ft.Tab(
                            text="Pronunciation",
                            content=ft.Text("This is Tab 3"),
                        ),
                        ft.Tab(
                            text="Allophony",
                            content=ft.Text("This is Tab 3"),
                        ),
                        ft.Tab(
                            text="Orthography",
                            content=ft.Text("This is Tab 2"),
                        ),
                        ft.Tab(
                            text="Inflection",
                            content=ft.Column([ft.Text("Nouns"), self.information["inflection_cases"], self.information["inflection_number"], self.information["inflection_gender"]])
                        ),
                    ],
                    expand=True,
                )
        )
        ### SOUND CHANGES
        right_content.append(
            ft.SafeArea(
                ft.Column(
                [
                    ft.Row(
                        [self.sound_changes["lock"], ft.FloatingActionButton(icon=ft.icons.ARROW_BACK, on_click = lambda e: self.SCNavSlide(-1)), self.sound_changes["slider"], ft.FloatingActionButton(icon=ft.icons.ARROW_FORWARD, on_click = lambda e: self.SCNavSlide(1)), self.sound_changes["addsc"], self.sound_changes["deletesc"], self.sound_changes["move_back"], self.sound_changes["move_forward"]]
                    ),
                    ft.Row(
                        [self.sound_changes["sc_summary"], self.sound_changes["sc_counter"]]
                    ),
                    ft.Tabs(
                        tabs=[
                            ft.Tab(
                                text="Prose",
                                content=ft.Column([ft.Text(""), ft.Row([self.sound_changes["newchapter"]]), ft.Row([self.sound_changes["prose"]])])
                            ),
                            ft.Tab(
                                text="Preview",
                                content=ft.Column([ft.Text(""), ft.Row([self.sound_changes["prose_rendered"]])])
                            ),
                            ft.Tab(
                                text="Regex",
                                content=ft.Column([ft.Text(""), self.sound_changes["regexentry"]])
                            ),
                            ft.Tab(
                                text="Advanced",
                                content=ft.Column([self.sound_changes["recursive"], ft.Row([ft.Text("Chance of occurring:"), self.sound_changes["sporadicityrate"]]), self.sound_changes["sporadicity"]])
                            ),
                            ft.Tab(
                                text="Internal Notes",
                                content=ft.Column([ft.Text(""), self.sound_changes["internalnotes"]])
                            )
                        ],
                        expand=True,
                    )
                ]
                ),
            )
        )
        ### GRAMMAR
        right_content.append(
            ft.Tabs(
                    tabs=[
                        ft.Tab(
                            text="Nouns",
                            content=ft.Column([ft.Row([self.grammar["noun_dropbox"], self.grammar["noun_add"]]), self.grammar["noun_name"], self.grammar["noun_datatable"]])
                        ),
                        ft.Tab(
                            text="Adjectives",
                            content=ft.Text("This is Tab 3"),
                        ),
                        ft.Tab(
                            text="Pronouns",
                            content=ft.Text("This is Tab 3"),
                        ),
                        ft.Tab(
                            text="Verbs",
                            content=ft.Text("This is Tab 2"),
                        ),
                    ],
                    expand=True,
                )
        )
        ### LEXICON
        editor_lexicon_cards = []
        for x in ["lexicontest", "lexi2", "lexi4"]:
            editor_lexicon_cards.append(ft.Card(
                content=ft.Container(
                    content=ft.Column(
                        [
                            ft.ListTile(
                                leading=ft.Icon(ft.icons.ALBUM),
                                title=ft.Text("entry"),
                                subtitle=ft.Text("translation"),
                            ),
                            ft.Row(
                                [ft.TextButton("Entry"), ft.TextButton("Sources")],
                                alignment=ft.MainAxisAlignment.END,
                            ),
                        ]
                    ),
                    width=400,
                    padding=10,
                )
            ))
        right_content.append(ft.Column(
            [
                ft.Row([
                    ft.TextField(label="Search…", adaptive=False, expand=True),
                    ft.FloatingActionButton(icon=ft.icons.FILTER_ALT, tooltip="Filter Entries"),
                    ft.FloatingActionButton(icon=ft.icons.ADD, tooltip="Add Entry", on_click = lambda e: self.page.open(self.lexicon_add_modal)),
                ]),
                ft.Row(controls=editor_lexicon_cards, wrap=True)
            ]
        ))
        ### TEXTS
        right_content.append(
            ft.Text("to do")
        )
        ### STATISTICS
        right_content.append(
            ft.Text("to do")
        )

        def updateRightContent(index):
            if self.mainState.sc_editing_mode == True:
                rail.selected_index = self.mainState.open_editor_tab
                self.page.update()
                self.alertdialog.title = ft.Text("Wait!")
                self.alertdialog.content = ft.Text("Please turn off sound change edit mode first.")
                self.page.open(self.alertdialog)
                return
            if self.mainState.open_stage == 0 and (index == 1 or index == 4):
                rail.selected_index = self.mainState.open_editor_tab
                self.page.update()
                self.alertdialog.title = ft.Text("Wait!")
                self.alertdialog.content = ft.Text("This feature is not supported for stage 0.")
                self.page.open(self.alertdialog)
                return
            if index == len(right_content): #saving
                self.saveDatabase()
                rail.selected_index = self.mainState.open_editor_tab
                self.page.update()
                return
            for y in right_content:
                y.visible = False
            right_content[index].visible = True
            self.mainState.open_editor_tab = index
            self.page.update()

        updateRightContent(self.mainState.open_editor_tab)
        self.updateSaveLook()

        ##### LAYOUT #####
        rail = ft.NavigationRail(
            selected_index = self.mainState.open_editor_tab,
            label_type=ft.NavigationRailLabelType.ALL,
            # extended=True,
            min_width=100,
            min_extended_width=400,
            leading=self.stageselect,
            group_alignment=-0.9,
            destinations=[
                ft.NavigationRailDestination(icon=ft.icons.INFO_OUTLINED, selected_icon=ft.icons.INFO_SHARP, label="Information"),
                ft.NavigationRailDestination(icon=ft.icons.INPUT_OUTLINED, selected_icon=ft.icons.INPUT_SHARP, label="Sound Changes"),
                ft.NavigationRailDestination(icon=ft.icons.TABLE_CHART_OUTLINED, selected_icon=ft.icons.TABLE_CHART_SHARP, label="Grammar"),
                ft.NavigationRailDestination(icon=ft.icons.BOOK_OUTLINED, selected_icon=ft.icons.BOOK_SHARP, label="Lexicon"),
                ft.NavigationRailDestination(icon=ft.icons.MESSAGE_OUTLINED, selected_icon=ft.icons.MESSAGE_SHARP, label="Texts"),
                ft.NavigationRailDestination(icon=ft.icons.INSERT_CHART_OUTLINED, selected_icon=ft.icons.INSERT_CHART_SHARP, label="Statistics"),
                self.savebutton,
            ],
            on_change=lambda e: updateRightContent(e.control.selected_index),
        )
        self.page.add(
            ft.Row(
                [
                    rail,
                    ft.VerticalDivider(width=1),
                    ft.Column(right_content, alignment=ft.MainAxisAlignment.START, expand=True),
                ],
                expand=True,
            )
        )

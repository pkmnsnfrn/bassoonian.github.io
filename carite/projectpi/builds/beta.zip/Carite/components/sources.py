import flet as ft

def sourcesSetUp(page, mainState):
    dataTableRows = []
    for entry in mainState.sources:
        dataTableRows.append(ft.DataRow(cells=[ft.DataCell(ft.Text(entry['title'])), ft.DataCell(ft.Text(entry['reference']))]))
    # add an empty row to account for the footer
    dataTableRows.append(ft.DataRow(cells=[ft.DataCell(ft.Text("")), ft.DataCell(ft.Text(""))]))

    page.add(
        ft.Column(
            [
                ft.DataTable(
                    columns=[
                        ft.DataColumn(ft.Text("Title")),
                        ft.DataColumn(ft.Text("Reference")),
                    ],
                    rows = dataTableRows,
                    width = page.width,
                ),
            ],
            scroll=ft.ScrollMode.ALWAYS,
            height = page.height
        )
    )

from enum import Enum, auto
import flet as ft

class WordTypes(Enum):
    ROOT = auto()
    VERB = auto()
    NOUN = auto()
    ADJECTIVE = auto()
    ADVERB = auto()
    PREPOSITION = auto()

WORDTYPEDATA = {
    WordTypes.ROOT : [ft.icons.ENERGY_SAVINGS_LEAF, "Root"],
    WordTypes.VERB : [ft.icons.DIRECTIONS_WALK, "Verb"],
    WordTypes.NOUN : [ft.icons.PERSON_ROUNDED, "Noun"],
    WordTypes.ADJECTIVE : [ft.icons.EQUALIZER, "Adjective"],
    WordTypes.ADVERB : [ft.icons.PAN_TOOL, "Adverb"],
    WordTypes.PREPOSITION : [ft.icons.MOVE_DOWN, "Preposition"]
}

class OriginLangs(Enum):
    LATIN = auto()
    ANCIENT_GREEK = auto()
    PROTO_CELTIC = auto()
    PUNIC = auto()
    ETRUSCAN = auto()
    EGYPTIAN = auto()

ORIGINLANGDATA = {
    OriginLangs.LATIN : "Latin",
    OriginLangs.ANCIENT_GREEK : "Ancient Greek",
    OriginLangs.PROTO_CELTIC : "Proto-Celtic",
    OriginLangs.PUNIC : "Punic",
    OriginLangs.ETRUSCAN : "Etruscan",
    OriginLangs.EGYPTIAN : "Egyptian"
}

import flet as ft

def CanSave(editorKeys):
    errors = []
    for stageid, stage in enumerate(editorKeys.mainState.database["stage_data"]):
        ### SOUND CHANGES ###
        for scid, sound_change in enumerate(stage["sound_changes"]):
            ## empty summaries are not allowed
            if sound_change["summary"].strip() == "":
                errors.append([stageid, "Sound Changes", "%s/%s missing summary!" % (scid + 1, len(stage["sound_changes"]))])
    if len(errors) == 0:
        return True

    editorKeys.warning("Error saving!", parseErrors(errors))
    return False

def parseErrors(errors):
    txt = ""
    for x in errors:
        if not txt == "":
            txt += "\n"
        txt += x[2]
    return txt

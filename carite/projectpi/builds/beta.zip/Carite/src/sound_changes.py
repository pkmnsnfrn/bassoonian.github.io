import re

def regex_to_editing_format(array):
    out = ""
    for x in array:
        if out != "":
            out += "\n"
        out+= "%s > %s" % (x[0], x[1])
    return out

def editing_format_to_regex(content):
    arr = []
    for x in content:
        if x.strip() == "":
            continue
        t = x.split(">")
        if len(t) != 2:
            return False
        if t[0].strip() == "" or t[1].strip() == "":
            return False
        arr.append(t)
    return arr

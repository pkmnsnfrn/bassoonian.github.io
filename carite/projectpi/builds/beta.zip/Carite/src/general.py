import json
import os
import flet as ft
import time

class MainState:
    def __init__(self, page):
        self.page = page
        # load sources
        with open("data/sources.json", "r", encoding='utf8') as f:
            self.sources = (json.load(f))['sources']

        # load preferences
        if os.path.exists("data/preferences.json"):
            with open("data/preferences.json", "r", encoding='utf8') as f:
                self.preferences = json.load(f)
        else:
            self.preferences = {
                "last_opened_stage": 0
            }

        # load data
        with open("data/database.json", "r", encoding='utf8') as f:
            self.database = json.load(f)

        # global session-exclusive variables
        self.has_changes = False
        self.open_editor_tab = 0
        self.open_bottom_tab = 0
        self.open_stage = self.preferences["last_opened_stage"]

        # sound changes
        self.sc_editing_mode = False
        # declensions
        self.declension_opened = -1
        # lexicon
        self.lexicon_entry_opened = -1

    def saveInformation(self):
        if self.has_changes == False:
            return
        with open("data/sources.json", "w", encoding='utf8') as f:
            json.dump({"sources": self.sources}, f, indent=4, ensure_ascii=False)
        with open("data/database.json", "w", encoding='utf8') as f:
            json.dump(self.database, f, indent=4, ensure_ascii=False)
        with open("data/preferences.json", "w", encoding='utf8') as f:
            json.dump(self.preferences, f, indent=4, ensure_ascii=False)
        self.has_changes = False
        self.page.title = self.page.title.replace("*", "")

def getEmptySoundChange(index):
    return {
        "summary": "SC%s" % index,
        "section": "",
        "prose": "",
        "internalnotes": "",
        "changes": "",
        "repeat": False,
        "rate": 100
    }

def getEmptyDeclension(name, cases, number):
    return {
        "name": name,
        "content": [["(0)"] * len(cases)] * len(number)
    }

def getEmptyLexicon(index):
    return {
        "rawword": "",
        "wordorigin": 0,  # derivation, etc
        "meanings": [],
        "components": [], # for derivations
        "originlang": 0,  # for loans
        "originword": "", # for loans
        "origintime": 0,  # before which sound change it was adopted
        "category": 0,    # noun etc
        "subcategory": 0, # eg o-stem
        "thinair": False, # for ex nihilo without scientific basis
        "internalnotes": "",
        "prose": ""
    }

def enableButton(btn):
    btn.disabled = False
    btn.bgcolor = None

def disableButton(btn):
    btn.disabled = True
    btn.bgcolor = ft.colors.SECONDARY

def arr_to_textbox(arr):
    return "\n".join(arr)

def textbox_to_arr(string):
    out = []
    for x in string.split("\n"):
        x = x.strip()
        if x != "":
            out.append(x)
    return out

def getUniqueId():
    return str(hex(int(time.time_ns()))).split("x")[1]

def getNameToId(dic):
    out = {}
    for x in dic:
        out[dic[x]["name"]] = x
    return out
